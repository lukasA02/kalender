<!DOCTYPE html>
<html lang="sv">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skapa användare</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Readex+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="test.css">
</head>

<body>
    <form action="spanvandare.php" method="GET">
        <div id="container">
            <div>
                <h1>Skapa användare</h1>
            </div>
            <div>
                <label for="Behorighet">Behörighet:</label>
                <input type="number" name="Behorighet">
            </div>
            <div>
                <label for="Anvnamn">Användarnamn:</label>
                <input name="Anvnamn" type="text">
            </div>
            <div>
                <label for="Losen">Lösenord:</label>
                <input name="Losen" type="text">
            </div>
            <div>
                <label for="Fnamn">Förnamn:</label>
                <input name="Fnamn" type="text">
            </div>
            <div>
                <label for="Enamn">Efternamn:</label>
                <input name="Enamn" type="text">
            </div>
            <div>
                <label for="Epost">Epost:</label>
                <input name="Epost" type="text">
            </div>
            <div>
                <label for="Telefon">Telefonnummer:</label>
                <input name="Telefon" type="text">
            </div>
            <div>
                <input id="submit" type="submit" value="Skapa">
            </div>
        </div>
    </form>
</body>

</html>