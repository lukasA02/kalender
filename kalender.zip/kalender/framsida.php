<?php
session_start();
?>
<!DOCTYPE html>
<html lang="sv">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EventhanterarN</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Readex+Pro&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="framsidastil.css">
</head>

<body>
    <h4 class="inloggad">Du är inloggad som: <?php echo $_SESSION['anv']; ?></h4>
    <a href="loggaut.php"><button class="loggaut">Logga ut</button></a>
    <div id="svamp">
        <span class="borta" onclick="tillbaka();" id="tillbaka">&#8592;</span>
        <ul class="flex-container">
            <li class="flex-item" onclick="anvandare();">Användare</li>
            <li class="flex-item" onclick="events();">Events</li>
            <a href="kalender.php">
                <li class="flex-item">Kalender</li>
            </a>
            <form class="" id="skapaanv" action="spanvandare.php" method="GET">
                <span class="grupp">
                    <input class="text" placeholder="Behörighet" type="number" name="Behorighet">
                </span>
                <span class="grupp">
                    <input class="text" placeholder="Användarnamn" name="Anvnamn" type="text">
                </span>
                <span class="grupp">
                    <input class="text" placeholder="Lösenord" name="Losen" type="text">
                </span>
                <span class="grupp">
                    <input class="text" placeholder="Förnamn" name="Fnamn" type="text">
                </span>
                <span class="grupp">
                    <input class="text" placeholder="Efternamn" name="Enamn" type="text">
                </span>
                <span class="grupp">
                    <input class="text" placeholder="Epost" name="Epost" type="text">
                </span>
                <span class="grupp">
                    <input class="text" placeholder="Telefonnummer" name="Telefon" type="text">
                </span>
                <span id="buttonspan">
                    <button type="submit" id="submit">&#8594;</button>
                </span>
            </form>
        </ul>
    </div>
    <div id="iram"><iframe id="anv" height="250" width="420" src="skapaanvandare.php"></iframe></div>
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
    <script src="framsidaskript.js"></script>
</body>

</html>