var knappar;

// sparar knappar och ersätter alla knappar med knappar relaterade till användare
function anvandare() {
    // visa tillbakaknappen
    $("#tillbaka").removeClass("borta");

    knappar = $(".flex-container").html();
    $(".flex-container").html("");
    $(".flex-container").append("<li onclick='skapaAnv();' class='flex-item'>Skapa användare</li>");
    $(".flex-container").append("<li class='flex-item' style='font-size: 15px'>Redigera användare</li>");
    $(".flex-container").append("<li class='flex-item'>Ta bort användare</li>");
    $(".flex-container").append("<li class='flex-item'>Visa användare</li>");
}

// sparar knappar och ersätter alla knappar med knappar relaterade till event
function events() {
    // visa tillbakaknappen
    $("#tillbaka").removeClass("borta");

    knappar = $(".flex-container").html();
    $(".flex-container").html("");
    $(".flex-container").append("<li class='flex-item'>Skapa event</li>");
    $(".flex-container").append("<li class='flex-item'>Ta bort event</li>");
    $(".flex-container").append("<li class='flex-item'>Redigera event</li>");
}

// tar tillbaka de senaste knapparna och tar bort tillbakaknappen
function tillbaka() {
    $(".flex-container").html(knappar);
    $("#tillbaka").addClass("borta");
}

function skapaAnv() {
    $("#skapaanv").removeClass("borta");
}

var i = 1;
var langd;

function input() {
    if (i < langd) {
        $('#skapaanv span.grupp:nth-child(' + i + ')').hide();
        $('#skapaanv span.grupp:nth-child(' + (i + 1) + ')').show();
        if (i == (langd - 1)) {
                $('#submit').hide();
            $('#buttonspan').append('<button type="submit">Skapa användare</button>');
        }
        i++;
    } else {
        $('#submit').hide();
        $('#buttonspan').append('<button type="submit">&#8594;</button>');
    }
}

$(function () {
    langd = $('#skapaanv span.grupp').length;
    $('#skapaanv span.grupp').hide();
    $('#skapaanv span.grupp:nth-child(1)').show();
    $('#submit').on('click', function (event) {
        event.preventDefault();
        input();
    });
});