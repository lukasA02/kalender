<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bjudain</title>
</head>
<body>

<div id="">
        <form action="bjudain.php" method="GET">
        <div class="box">
            <h1>Bjudain till Event 😀</h1>
        </div>
        <div class="box">
        <label for="EventID">Event ID:</label>
         <input type="number" name="EventID" >   
        </div>
        <div class="box">
            <label for="anvid">ID på vem du sak bjudain:</label>
            <input  name="anvid" type="number">
        </div>
        <div id="login" class="box">
            <input type="submit" value="lägg till">
        </div>
    </form>

</div>
    
</body>
</html>